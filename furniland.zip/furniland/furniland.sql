-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2025 at 06:38 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `furniland`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `CartID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `ProductID` int(11) DEFAULT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`CartID`, `UserID`, `ProductID`, `Quantity`) VALUES
(11, 6, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ProductID` int(11) NOT NULL,
  `ProductName` varchar(30) NOT NULL,
  `Description` text NOT NULL,
  `Price` int(11) NOT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `VendorID` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ProductID`, `ProductName`, `Description`, `Price`, `Image`, `VendorID`, `category_id`) VALUES
(1, 'Sigma Sliding Wardrobe', 'Lemari Pakaian Geser Sigma adalah solusi penyimpanan yang cerdas dan hemat ruang untuk kamar tidur modern. Pintu geser (sliding doors) menghilangkan kebutuhan akan ruang kosong di depan lemari, menjadikannya sempurna untuk ruangan sempit atau kamar dengan tata letak padat. Desainnya yang ramping dan minimalis, seringkali dengan finishing high-gloss atau cermin, memberikan tampilan yang bersih dan elegan, sekaligus membantu memantulkan cahaya untuk memperluas visual ruangan.', 7200000, '1765704018_images (1).jpeg', 1, NULL),
(2, 'Set Meja Makan Jati Minimalis', 'Set Meja Makan Kayu Jati Minimalis ini adalah investasi jangka panjang untuk ruang makan Anda. Dibuat menggunakan 100% kayu Jati solid pilihan, set ini dikenal karena kekuatan, ketahanan terhadap hama, dan daya tahannya yang luar biasa. Desainnya yang minimalis dan bersih menonjolkan serat alami kayu Jati, memberikan sentuhan elegan dan hangat. Set ini ideal untuk penggunaan sehari-hari maupun acara spesial.', 8500000, '1765704185_meja-makan-minimalis-kayu-jati-elegant-jepara.jpg', 3, NULL),
(3, 'Rak Buku Dinding Tiga Tingkat', 'Rak Buku Dinding Tiga Tingkat adalah solusi penyimpanan vertikal yang sempurna untuk memaksimalkan ruang di rumah atau apartemen kecil. Dengan desain melayang (floating design), rak ini memberikan tampilan minimalis, modern, dan tidak membebani ruangan. Setiap tingkat menawarkan kapasitas yang cukup untuk menampung koleksi buku, tanaman hias, atau pajangan dekorasi favorit Anda.', 950000, '1765704240_10482150_1.jpg', 2, NULL),
(4, 'Kursi Kerja Ergonomis Hitam', 'Kursi Kerja Ergonomis Mesh Hitam dirancang khusus untuk mendukung postur tubuh Anda selama jam kerja yang panjang. Dilengkapi dengan penyangga pinggang (lumbar support) yang dapat disesuaikan dan sandaran kepala yang adaptif, kursi ini mengurangi tekanan pada punggung bawah dan leher. Material mesh berteknologi tinggi memastikan sirkulasi udara maksimal, menjaga Anda tetap sejuk dan fokus sepanjang hari tanpa rasa gerah.', 2890000, '1765707612_MYRA_NO_HEADREST.jpg', 1, NULL),
(5, 'Meja Kopi Bundar Kaca dan Besi', 'Meja Kopi Bundar Kaca dan Besi adalah perpaduan sempurna antara kekuatan industrial dan keanggunan minimalis. Permukaan kaca bening berdiameter besar menciptakan ilusi ruang yang lebih luas dan menampilkan detail rangka besi tempa yang kokoh. Desain bundar memastikan keamanan dan aliran yang mulus di ruang tamu, cocok untuk interior modern, minimalis, atau kontemporer.', 1250000, '1765707668_images.jpeg', 3, NULL),
(6, 'Lampu Lantai Industrial', 'Lampu Lantai Berdiri Industrial dirancang untuk membawa nuansa vintage yang berani dan elegan ke ruang Anda. Dengan finishing logam hitam matte dan detail exposed bulb, lampu ini menangkap esensi desain industrial modern. Cocok sebagai statement piece di sudut ruang tamu atau kantor, memberikan penerangan terarah yang hangat dan berkarakter.', 780000, '1765707729_images (1).jpeg', 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transactiondetails`
--

CREATE TABLE `transactiondetails` (
  `DetailID` int(11) NOT NULL,
  `TransactionID` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Subtotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactiondetails`
--

INSERT INTO `transactiondetails` (`DetailID`, `TransactionID`, `ProductID`, `Quantity`, `Subtotal`) VALUES
(1, 1, 3, 1, 950000),
(2, 2, 3, 1, 950000),
(3, 3, 1, 2, 14400000),
(4, 3, 2, 1, 8500000),
(5, 4, 2, 1, 8500000),
(6, 4, 3, 1, 950000),
(7, 5, 5, 1, 1250000),
(8, 6, 5, 1, 1250000),
(9, 6, 6, 2, 1560000);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `TransactionID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `TransactionDate` datetime DEFAULT current_timestamp(),
  `TotalPrice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`TransactionID`, `UserID`, `TransactionDate`, `TotalPrice`) VALUES
(1, 6, '2025-12-14 17:02:13', 950000),
(2, 6, '2025-12-14 17:02:26', 950000),
(3, 6, '2025-12-14 17:03:14', 22900000),
(4, 6, '2025-12-14 17:14:22', 9450000),
(5, 6, '2025-12-14 18:54:39', 1250000),
(6, 6, '2025-12-14 19:11:13', 2810000);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Gender` enum('Male','Female') NOT NULL,
  `DOB` date NOT NULL,
  `Role` enum('Admin','Member') DEFAULT 'Member'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `Username`, `Email`, `Password`, `Gender`, `DOB`, `Role`) VALUES
(1, 'admin', 'admin@gmail.com', '0192023a7bbd73250516f069df18b500', 'Male', '1990-01-01', 'Admin'),
(2, 'steven', 'stevehuang156@gmail.com', '$2y$10$SI8C/JWD3x2rPDi57dcZd.N.b7ahd4FPihbfHzLWs9Qei7IT6SUuK', 'Male', '2025-12-03', 'Admin'),
(5, 'nico', 'nico@gmail.com', '$2y$10$xoJz0cBILfp6PbZJvKIl9.VdOo8igt03uxCzu3VoTisBx5AkVm9cS', 'Male', '2025-12-10', 'Admin'),
(6, 'nicolamarvel', 'nicolamarvel@gmail.com', '$2y$10$LaQ1LAajHpmGTiEaqLJ2geCLZBcl7eKLIicjSCd9rmZuB0i8aeTmG', 'Male', '2025-12-14', 'Member');

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `VendorID` int(11) NOT NULL,
  `VendorName` varchar(20) NOT NULL,
  `VendorLocation` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`VendorID`, `VendorName`, `VendorLocation`) VALUES
(1, 'UrbanNest', 'Surabaya, East Java'),
(2, 'Nordico', 'Yogyakarta, DIY'),
(3, 'Rustika', 'Jakarta Selatan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`CartID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `ProductID` (`ProductID`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ProductID`),
  ADD KEY `VendorID` (`VendorID`),
  ADD KEY `fk_products_category` (`category_id`);

--
-- Indexes for table `transactiondetails`
--
ALTER TABLE `transactiondetails`
  ADD PRIMARY KEY (`DetailID`),
  ADD KEY `TransactionID` (`TransactionID`),
  ADD KEY `ProductID` (`ProductID`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`TransactionID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`VendorID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `CartID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `transactiondetails`
--
ALTER TABLE `transactiondetails`
  MODIFY `DetailID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `TransactionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `VendorID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `products` (`ProductID`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`VendorID`) REFERENCES `vendors` (`VendorID`);

--
-- Constraints for table `transactiondetails`
--
ALTER TABLE `transactiondetails`
  ADD CONSTRAINT `transactiondetails_ibfk_1` FOREIGN KEY (`TransactionID`) REFERENCES `transactions` (`TransactionID`),
  ADD CONSTRAINT `transactiondetails_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `products` (`ProductID`);

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
