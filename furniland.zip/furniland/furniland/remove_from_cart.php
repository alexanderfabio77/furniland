<?php
require "config/db.php";
session_start();

$id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM cart WHERE CartID=?");
$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: cart.php");
exit;
