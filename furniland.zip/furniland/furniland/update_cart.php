<?php
require "config/db.php";
session_start();

$cartID = $_POST['cart_id'];
$qty = $_POST['quantity'];

$query = "UPDATE cart SET Quantity=? WHERE CartID=?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $qty, $cartID);
$stmt->execute();

header("Location: cart.php");
exit;
