<?php
require "../config/db.php";
require "../middleware/admin.php";


$search = $_GET['search'] ?? '';
$vendorFilter = $_GET['vendor'] ?? '';


$vendorList = $conn->query("SELECT VendorID, VendorName FROM vendors");


$sql = "SELECT p.ProductID, p.ProductName, p.Price, p.Image, v.VendorName
        FROM products p 
        JOIN vendors v ON p.VendorID = v.VendorID
        WHERE 1";

if ($search !== "") {
    $sql .= " AND p.ProductName LIKE '%" . $conn->real_escape_string($search) . "%'";
}

if ($vendorFilter !== "") {
    $sql .= " AND p.VendorID = " . intval($vendorFilter);
}

$sql .= " ORDER BY p.ProductID DESC";
$products = $conn->query($sql);

$username = $_SESSION['username'] ?? 'Admin'; 
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Manage Products</title>

<style>
    body {
        margin: 0;
        background-color: #0f1b2b;
        color: white;
        font-family: Arial, sans-serif;
    }

    
    nav {
        background: #14263d; 
        padding: 14px 30px; 
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
   
    .nav-group {
        display: flex;
        align-items: center;
        gap: 15px; 
    }

    
    nav a {
        color: #d0e8ff; 
        text-decoration: none;
        font-size: 14px;
        margin: 0;
        padding: 5px 0;
    }
    nav a:hover { color:#00c8ff }

    
    .logo {
        font-weight: bold;
        font-size: 18px; 
        color: #e5f1ff !important; 
        text-decoration: none;
        margin-right: 10px;
    }
    .logo:hover {
        color: #00c8ff !important;
    }
    
    
    .logout-link {
        color: #ff6b6b !important;
    }

    .container {
        padding: 40px 50px;
    }

    
    .top-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 18px;
    }

    .add-btn {
        background:#0096d1;
        padding:10px 16px;
        color:white;
        text-decoration:none;
        border-radius:6px;
        font-size:14px;
    }
    .add-btn:hover { background:#00a8f0; }

    
    .filters {
        display: flex;
        gap: 12px;
        margin-bottom: 20px;
    }

    .filters input,
    .filters select {
        padding: 10px;
        background-color: #132737;
        border: 1px solid #1f3a50;
        color: white;
        border-radius: 6px;
    }

    
    table {
        width: 100%;
        border-collapse: collapse;
        background-color: #132737;
        border-radius: 8px;
        overflow: hidden;
    }
    th, td {
        padding: 12px;
        border-bottom: 1px solid #1f3a50;
    }
    th {
        background-color: #173556;
        font-weight: bold;
    }
    tr:hover { background-color:#1f3f63; }

    img.thumb {
        width:60px; 
        height:60px;
        object-fit:cover;
        border-radius:4px;
    }

    .actions a {
        color:#4fd2ff;
        margin-right:10px;
        text-decoration:none;
    }
    .actions .delete { color:#ff6b6b; }

</style>
</head>
<body>

<nav>
    <div class="nav-group">
        <a href="../home.php" class="logo">Furniland</a>
        <a href="../home.php">Dashboard</a>
    </div>

    <div class="nav-group">
        <a href="../profile.php" style="color: #4fd2ff;"><?= htmlspecialchars($username) ?> (Admin)</a>
        <a href="../logout.php" class="logout-link">Logout</a>
    </div>
</nav>

<div class="container">

    <div class="top-row">
        <h1 style="margin:0;">Manage Products</h1>
        <a href="create.php" class="add-btn">+ Add Product</a>
    </div>

    <form method="GET" class="filters">
        <input type="text" name="search" placeholder="Search product name..."
               value="<?= htmlspecialchars($search) ?>">

        <select name="vendor">
            <option value="">Filter by vendor</option>
            <?php while ($v = $vendorList->fetch_assoc()): ?>
                <option value="<?= $v['VendorID'] ?>"
                    <?= ($vendorFilter == $v['VendorID']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($v['VendorName']) ?>
                </option>
            <?php endwhile; ?>
        </select>

        <button style="background:#0096d1; border:none; padding:10px 14px; border-radius:6px; color:white; cursor:pointer;">
            Apply
        </button>
    </form>

    <table>
        <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Price</th>
            <th>Vendor</th>
            <th>Actions</th>
        </tr>

        <?php if ($products->num_rows > 0): ?>
            <?php while ($p = $products->fetch_assoc()): ?>
                <tr>
                    <td>
                        <?php if (!empty($p['Image'])): ?>
                            <img class="thumb" src="../uploads/<?= htmlspecialchars($p['Image']) ?>">
                        <?php endif; ?>
                    </td>

                    <td><?= htmlspecialchars($p['ProductName']) ?></td>

                    <td>Rp <?= number_format($p['Price'], 0, ',', '.') ?></td>

                    <td><?= htmlspecialchars($p['VendorName']) ?></td>

                    <td class="actions">
                        <a href="edit.php?id=<?= $p['ProductID'] ?>">Edit</a>
                        <a href="delete.php?id=<?= $p['ProductID'] ?>" class="delete"
                            onclick="return confirm('Delete this product?');">
                            Delete
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="5" style="text-align:center; padding:20px;">
                    No products found.
                </td>
            </tr>
        <?php endif; ?>

    </table>
</div>

</body>
</html>