<?php
require "../config/db.php";
require "../middleware/admin.php";

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = intval($_GET['id']);
$errors = [];


$vendorList = $conn->query("SELECT VendorID, VendorName FROM vendors");


$stmt = $conn->prepare("SELECT * FROM products WHERE ProductID=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    header("Location: index.php");
    exit;
}


$post_name = $_POST['name'] ?? $product['ProductName'];
$post_price = $_POST['price'] ?? $product['Price'];
$post_vendor = $_POST['vendor'] ?? $product['VendorID'];

$post_description = $_POST['description'] ?? $product['Description'];

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = trim($_POST['name']);
    $price = trim($_POST['price']);
    $vendor = intval($_POST['vendor']);
    $description = trim($_POST['description']); 

    $oldImg = $product['Image'];
    $newImg = $oldImg;

    if ($name === "") $errors[] = "Product name cannot be empty.";
    if (!is_numeric($price) || $price < 0) $errors[] = "Invalid price.";
    if ($vendor <= 0) $errors[] = "Please select a vendor.";
    
    if (strlen($description) < 10) $errors[] = "Product description must be at least 10 characters.";


    if (!empty($_FILES['image']['name'])) {

        $dir = "../uploads/";
        if (!is_dir($dir)) mkdir($dir, 0777, true);

        $fileName = time() . "_" . basename($_FILES['image']['name']);
        $target = $dir . $fileName;

        $ext = strtolower(pathinfo($target, PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg','jpeg','png','webp'])) {
            $errors[] = "Image must be JPG, JPEG, PNG, or WEBP.";
        } else {
           
            if (empty($errors)) {
                if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                    $newImg = $fileName;
    
                    if (!empty($oldImg) && file_exists("../uploads/".$oldImg)) {
                        unlink("../uploads/".$oldImg);
                    }
                } else {
                    $errors[] = "Failed to upload image.";
                }
            }
        }
    }

    if (empty($errors)) {
        
        $update = $conn->prepare("UPDATE products SET ProductName=?, Price=?, VendorID=?, Image=?, Description=? WHERE ProductID=?");
        $update->bind_param("siissi", $name, $price, $vendor, $newImg, $description, $id);
        $update->execute();

        
        header("Location: index.php");
        exit;
    }
}

$username = $_SESSION['username'] ?? 'Admin';
?>
<!DOCTYPE html>
<html>
<head>
<title>Edit Product</title>

<style>
    body {
        margin:0;
        background:#0b1522;
        color:white;
        font-family:Arial, sans-serif;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }
    
    
    nav {
        background:#14263d;
        padding:14px 30px; 
        display:flex;
        justify-content:space-between;
        align-items:center;
    }
    .nav-group {
        display: flex;
        align-items: center;
        gap: 15px;
    }
    .logo {
        font-weight:bold;
        font-size:18px; 
        color: #e5f1ff !important; 
        text-decoration: none;
        margin-right: 10px;
    }
    .logo:hover {
        color: #00c8ff !important;
    }
    nav a {
        color:#d0e8ff;
        text-decoration:none;
        font-size:14px;
        margin: 0;
        padding: 5px 0;
    }
    nav a:hover { color:#00c8ff; }
    .username-link {
        color:#4fd2ff !important;
    }
    .logout-link {
        color:#ff6b6b !important;
    }

    
    .container {
        width: 450px; 
        margin: 50px auto;
        flex-grow: 1; 
        background-color: #122030;
        border: 1px solid #1f3a50;
        padding: 30px; 
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
    }
    
    h2 {
        font-size: 24px;
        font-weight: bold;
        margin-top: 0;
        margin-bottom: 25px;
        color: #d0e8ff;
    }

    
    input, select, textarea { 
        width: 100%;
        padding: 10px;
        margin-top: 6px;
        margin-bottom: 15px;
        border-radius: 4px;
        border: 1px solid #35506b;
        background-color: #0f1b2b; 
        color: white;
        box-sizing: border-box; 
        transition: border-color 0.3s;
    }
    input:focus, select:focus, textarea:focus { 
        border-color: #4fd2ff; 
        outline: none;
    }
    textarea {
        resize: vertical; 
        min-height: 100px;
    }

    label {
        display: block;
        margin-top: 15px;
        margin-bottom: 5px;
        font-size: 14px;
        color: #d0e8ff;
        font-weight: bold;
    }
    
    /* BUTTON */
    button {
        width: 100%;
        padding: 12px;
        margin-top: 20px;
        border: none;
        border-radius: 4px;
        background-color: #0088cc; 
        color: white;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        transition: background-color 0.2s;
    }
    button:hover { background-color: #00aaff; }

    /* ERROR MESSAGE STYLING */
    .error-container {
        color: #ff6b6b;
        margin-bottom: 20px;
        padding: 10px 15px;
        border: 1px solid #ff6b6b;
        background: rgba(255, 107, 107, 0.1);
        border-radius: 4px;
        font-size: 14px;
    }
    .error-container ul {
        margin: 0;
        padding-left: 20px;
    }

    /* IMAGE PREVIEW */
    img.preview {
        width:120px;
        height:120px;
        object-fit:cover;
        border-radius:6px;
        margin-top: 10px;
        border: 1px solid #35506b;
    }

    /* FOOTER */
    footer{
        background:#0d1826;
        color:#9bb4cc;
        text-align:center;
        padding:18px;
        font-size:13px;
        border-top:1px solid #23384d;
        margin-top: auto;
    }
</style>
</head>

<body>

<nav>
    <div class="nav-group">
        <a href="../home.php" class="logo">Furniland</a>
        <a href="../home.php">Dashboard</a>
    </div>

    <div class="nav-group">
        <a href="../profile.php" class="username-link"><?= htmlspecialchars($username) ?> (Admin)</a>
        <a href="../logout.php" class="logout-link">Logout</a>
    </div>
</nav>


<div class="container">
    <h2>Edit Product</h2>

    <?php if (!empty($errors)): ?>
        <div class="error-container">
            <ul>
            <?php foreach ($errors as $e): ?>
                <li><?= htmlspecialchars($e) ?></li>
            <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <label for="product_name">Name</label>
        <input type="text" id="product_name" name="name" value="<?= htmlspecialchars($post_name) ?>">

        <label for="product_price">Price</label>
        <input 
            type="number" 
            id="product_price"
            name="price" 
            min="0"
            step="1"
            value="<?= htmlspecialchars($post_price) ?>" 
            required
        >

        <label for="product_description">Description</label>
        <textarea id="product_description" name="description" required><?= htmlspecialchars($post_description) ?></textarea>
        <label for="vendor_select">Vendor</label>
        <select name="vendor" id="vendor_select">
            <option value="">Select Vendor</option>
            <?php 
            $vendorList->data_seek(0); 
            while ($v = $vendorList->fetch_assoc()): 
            ?>
                <option value="<?= $v['VendorID'] ?>" 
                    <?= ($post_vendor == $v['VendorID']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($v['VendorName']) ?>
                </option>
            <?php endwhile; ?>
        </select>

        <label>Current Image</label><br>
        <?php if (!empty($product['Image'])): ?>
            <img class="preview" src="../uploads/<?= htmlspecialchars($product['Image']) ?>">
        <?php else: ?>
            <p style="margin-top: 10px; font-style: italic; color: #a0a0a0; font-size: 14px;">No image uploaded.</p>
        <?php endif; ?>
        <br>
        
        <label for="image_replace">Replace Image (optional)</label>
        <input type="file" id="image_replace" name="image" accept="image/*">

        <button>Update Product</button>
    </form>
</div>

<footer>
    © 2025 Furniland. All rights reserved.<br>
    Contact: furniland-support@gmail.com
</footer>

</body>
</html>