<?php
require "../config/db.php";
require "../middleware/admin.php";

if (!isset($_GET['id']) || !ctype_digit($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = (int)$_GET['id'];

$conn->begin_transaction();

try {
    
    $stmt1 = $conn->prepare(
        "DELETE FROM transactiondetails WHERE ProductID = ?"
    );
    $stmt1->bind_param("i", $id);
    $stmt1->execute();

    
    $stmt2 = $conn->prepare(
        "DELETE FROM products WHERE ProductID = ?"
    );
    $stmt2->bind_param("i", $id);
    $stmt2->execute();

    $conn->commit();
    header("Location: index.php");
    exit;

} catch (Exception $e) {
    $conn->rollback();
    die("Delete gagal: ".$e->getMessage());
}
