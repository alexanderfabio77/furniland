<?php
require "../config/db.php";
require "../middleware/admin.php";

$errors = [];
$success = "";


$vendors = $conn->query("SELECT VendorID, VendorName FROM vendors");


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name   = trim($_POST['name'] ?? '');
    $price  = trim($_POST['price'] ?? '');
    $vendor = intval($_POST['vendor'] ?? 0);
    $image  = "";

    
    if ($name === "") {
        $errors[] = "Product name cannot be empty.";
    }

    if ($price === "" || !is_numeric($price) || $price < 0) {
        $errors[] = "Price must be a valid non-negative number.";
    }

    if ($vendor <= 0) {
        $errors[] = "Please select a vendor.";
    }

    
    if (!empty($_FILES['image']['name'])) {

        $targetDir = "../uploads/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }

        $fileName = time() . "_" . basename($_FILES["image"]["name"]);
        $targetFile = $targetDir . $fileName;

        $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

      
        $allowedTypes = ['jpg','jpeg','png','webp'];

        if (!in_array($fileType, $allowedTypes)) {
            $errors[] = "Only JPG, JPEG, PNG, and WEBP files are allowed.";
        }

        if (empty($errors)) {
           
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
                $image = $fileName;
            } else {
               
                $errors[] = "Failed to upload file."; 
            }
        }
    }

  
    if (empty($errors)) {

        $sql = "INSERT INTO products (ProductName, Price, VendorID, Image)
                  VALUES (?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("siis", $name, $price, $vendor, $image);

        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            
            $errors[] = "Failed to add product: " . $conn->error; 
        }
    }
}
$username = $_SESSION['username'] ?? 'Admin';
?>
<!DOCTYPE html>
<html>
<head>
<title>Add Product</title>

<style>
    body {
        
        background-color: #0b1522;
        color: white;
        font-family: Arial, sans-serif;
        margin: 0;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }

    
    nav {
        background-color: #14263d;
        padding: 14px 30px; 
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
 
    .nav-group {
        display: flex;
        align-items: center;
        gap: 15px;
    }
  
    .logo {
        font-weight: bold;
        font-size: 18px; 
        color: #e5f1ff !important; 
        text-decoration: none;
        margin-right: 10px;
    }
    .logo:hover {
        color: #00c8ff !important;
    }
    
    nav a {
        color: #d0e8ff;
        text-decoration: none;
        font-size: 14px;
        margin: 0;
        padding: 5px 0;
    }
    nav a:hover { color:#00c8ff; }
    
    
    .username-link {
        color:#4fd2ff !important;
    }
    .logout-link {
        color:#ff6b6b !important;
    }


    
    .container {
        width: 450px; 
        margin: 50px auto;
        flex-grow: 1;
        
        background-color: #122030;
        border: 1px solid #1f3a50;
        padding: 30px; 
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
    }
    
   
    h2 {
        font-size: 24px;
        font-weight: bold;
        margin-top: 0;
        margin-bottom: 25px;
        color: #d0e8ff;
    }

    
    input, select {
        width: 100%;
        padding: 10px;
        margin-top: 6px;
        margin-bottom: 15px; 
        border-radius: 4px;
        
        border: 1px solid #35506b;
        background-color: #0f1b2b; 
        color: white;
        box-sizing: border-box; 
        transition: border-color 0.3s;
    }
    input:focus, select:focus {
        border-color: #4fd2ff; 
        outline: none;
    }

    label {
        display: block;
        margin-top: 15px;
        margin-bottom: 5px;
        font-size: 14px;
        color: #d0e8ff;
        font-weight: bold;
    }

 
    button {
        width: 100%;
        padding: 12px;
        border-radius: 4px;
        border: none;
        cursor: pointer;
        font-size: 16px;
        font-weight: bold;
       
        background-color: #0088cc;
        color: white;
        margin-top: 20px;
        transition: background-color 0.2s;
    }
    button:hover {
        background-color: #00aaff;
    }

   
    .error-container {
        color: #ff6b6b;
        margin-bottom: 20px;
        padding: 10px 15px;
        border: 1px solid #ff6b6b;
        background: rgba(255, 107, 107, 0.1);
        border-radius: 4px;
        font-size: 14px;
    }
    .error-container ul {
        margin: 0;
        padding-left: 20px;
    }

  
    footer{
        background:#0d1826;
        color:#9bb4cc;
        text-align:center;
        padding:18px;
        font-size:13px;
        border-top:1px solid #23384d;
        margin-top: auto;
    }
</style>
</head>

<body>

<nav>
    <div class="nav-group">
        <a href="../home.php" class="logo">Furniland</a>
        <a href="../home.php">Dashboard</a>
    </div>

    <div class="nav-group">
        <a href="../profile.php" class="username-link"><?= htmlspecialchars($username) ?> (Admin)</a>
        <a href="../logout.php" class="logout-link">Logout</a>
    </div>
</nav>


<div class="container">
    <h2>Add New Product</h2>

    <?php if (!empty($errors)): ?>
        <div class="error-container">
            <ul>
                <?php foreach ($errors as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">

        <label for="product_name">Product Name</label>
        <input type="text" id="product_name" name="name" value="<?= $_POST['name'] ?? '' ?>">

        <label for="product_price">Price</label>
        <input 
            type="number" 
            id="product_price"
            name="price" 
            min="0"
            step="1"
            value="<?= $_POST['price'] ?? '' ?>" 
            required
        >


        <label for="vendor_select">Vendor</label>
        <select name="vendor" id="vendor_select">
            <option value="">Select vendor</option>
            <?php 
            
            $vendors->data_seek(0);
            while ($v = $vendors->fetch_assoc()): 
            ?>
                <option value="<?= $v['VendorID'] ?>"
                    <?= (($_POST['vendor'] ?? '') == $v['VendorID']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($v['VendorName']) ?>
                </option>
            <?php endwhile; ?>
        </select>

        <label for="product_image">Image (optional)</label>
        <input type="file" id="product_image" name="image" accept="image/*">

        <button>Add Product</button>
    </form>
</div>

<footer>
    © 2025 Furniland. All rights reserved.<br>
    Contact: furniland-support@gmail.com
</footer>

</body>
</html>