<?php
require "config/db.php";
session_start();


if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== "Member") {
    header("Location: auth/login.php");
    exit;
}

$userID    = $_SESSION['user_id'];
$productID = (int) ($_POST['product_id'] ?? 0);
$qty       = (int) ($_POST['qty'] ?? 1);

if ($productID <= 0 || $qty <= 0) {
    header("Location: catalog.php");
    exit;
}


$sql = "SELECT Quantity FROM cart WHERE UserID = ? AND ProductID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $userID, $productID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    
    $update = $conn->prepare("
        UPDATE cart 
        SET Quantity = Quantity + ? 
        WHERE UserID = ? AND ProductID = ?
    ");
    $update->bind_param("iii", $qty, $userID, $productID);
    $update->execute();
} else {
    
    $insert = $conn->prepare("
        INSERT INTO cart (UserID, ProductID, Quantity)
        VALUES (?, ?, ?)
    ");
    $insert->bind_param("iii", $userID, $productID, $qty);
    $insert->execute();
}

header("Location: cart.php");
exit;
