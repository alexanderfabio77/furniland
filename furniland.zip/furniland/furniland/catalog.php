<?php
require "config/db.php";
session_start();

$role     = $_SESSION['role']     ?? 'Guest';
$username = $_SESSION['username'] ?? null;

$vendors = $conn->query("SELECT VendorID, VendorName FROM vendors ORDER BY VendorName");

$search   = trim($_GET['search'] ?? '');
$vendorId = $_GET['vendor'] ?? '';
$sort     = $_GET['sort'] ?? '';

$sql = "SELECT p.ProductID, p.ProductName, p.Price, p.Image, v.VendorName
        FROM products p
        JOIN vendors v ON p.VendorID = v.VendorID
        WHERE 1=1";

$params = [];
$types  = "";

if ($search !== '') {
    $sql .= " AND (p.ProductName LIKE ?)";
    $like = "%$search%";
    $params[] = &$like;
    $types .= "s";
}

if ($vendorId !== '') {
    $vid = (int)$vendorId;
    $sql .= " AND p.VendorID = ?";
    $params[] = &$vid;
    $types .= "i";
}

switch ($sort) {
    case "name_asc":   $sql .= " ORDER BY p.ProductName ASC"; break;
    case "name_desc":  $sql .= " ORDER BY p.ProductName DESC"; break;
    case "price_asc":  $sql .= " ORDER BY p.Price ASC"; break;
    case "price_desc": $sql .= " ORDER BY p.Price DESC"; break;
    default:           $sql .= " ORDER BY p.ProductID DESC";
}

$stmt = $conn->prepare($sql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$products = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
<title>Product Catalog - Furniland</title>

<style>
body{
    margin:0;
    
    background:linear-gradient(#0f1b2b,#0b1522);
    color:#fff;
    font-family:Arial, sans-serif;
    display:flex;
    flex-direction:column;
    min-height:100vh;
}
main{ flex: 1; } 

/* --- CSS NAV BAR SINKRONISASI --- */
nav{
    background:#14263d; 
    padding:14px 30px; 
    display:flex;
    justify-content:space-between;
    align-items:center;
}
.nav-group {
    display: flex;
    align-items: center;
    gap: 15px; 
}
.logo{
    font-size:20px;
    font-weight:bold;
    color: #e5f1ff !important;
    text-decoration: none;
    margin-right: 10px;
}
nav a{
    color:#d0e8ff; 
    text-decoration:none;
    font-size:14px;
    margin: 0; 
    padding: 5px 0; 
}
nav a:hover{color:#00c8ff}

/* CLASS AKTIF & DANGER */
nav a.nav-active {
    color: #4fd2ff !important; 
    font-weight: bold;
}
nav a.nav-danger {
    color: #ff6b6b !important;
}
/* ---------------------------------- */


.header{
    text-align:center;
    margin:35px 0 30px; 
}
.header h1{margin:0; font-size: 32px;}
.header p{color:#9bb4cc;margin-top:6px; font-size: 16px;}


.filter-bar{
    max-width: 1400px;
    margin:0 auto 30px;
    background:#122030; 
    border:1px solid #1f3a50; 
    border-radius:10px;
    padding:18px 25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:20px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.filter-left,
.filter-right{
    display:flex;
    gap:10px;
    align-items:center;
}

.filter-bar input,
.filter-bar select{
    background:#0f1b2b; 
    border:1px solid #35506b;
    color:#fff;
    padding:10px 12px; 
    border-radius:6px;
    font-size: 14px;
    transition: border-color 0.2s;
}

.filter-bar input:focus,
.filter-bar select:focus {
    outline: none;
    border-color: #4fd2ff;
}

.filter-bar button{
    background:#0088cc; 
    border:none;
    padding:10px 20px;
    color:#fff;
    border-radius:6px;
    cursor:pointer;
    font-weight: bold;
    transition: background 0.2s;
}
.filter-bar button:hover{background:#00aaff}


.grid{
    max-width: 1400px;
    margin: 0 auto;
    padding:30px;
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(250px,1fr)); 
    gap:25px;
}
.card{
    background: #0d1721; 
    border: none; 
    border-radius: 8px; 
    padding: 15px; 
    display:flex;
    flex-direction:column;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.card:hover {
    transform: translateY(-5px); 
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2); 
}

.card img{
    width:100%;
    height:180px; 
    object-fit:cover;
    border-radius:4px; 
    margin-bottom:12px;
}
.card h4{
    margin: 0 0 4px 0; 
    font-size: 18px;
    color: #e5f1ff;
}
.card small{
    color:#9bb4cc;
    font-size: 14px; 
    margin-bottom: 15px;
    flex-grow: 1; 
}
.price{
    margin:0 0 15px; 
    font-size: 20px;
    color: #38c6ff; 
    font-weight:bold;
}

.btn {
    margin-top:auto;
    background: #0088cc; 
    color: #fff;
    text-align: center;
    padding: 10px;
    border-radius: 4px; 
    text-decoration: none;
    font-weight: bold;
    transition: background 0.2s;
}
.btn:hover{background:#00aaff}


.no-products-message {
    width: 100%; 
    max-width: 1400px; 
    margin: 0 auto;
    padding: 60px 30px; 
    text-align: center;
    font-size: 18px;
    color: #9bb4cc;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 40vh; 
    flex-direction: column;
}


footer{
    margin-top:auto;
    background:#0d1826;
    border-top:1px solid #23384d;
    text-align:center;
    padding:18px;
    color:#9bb4cc;
    font-size:13px;
}
</style>
</head>
<body>

<nav>
    <div class="nav-group">
        <a href="home.php" class="logo">Furniland</a>
        <a href="home.php">Home</a>
        <a href="catalog.php" class="nav-active">Catalog</a> 
    </div>
    <div class="nav-group">
        <?php if ($role === 'Guest'): ?>
            <a href="auth/login.php" class="nav-active">Login</a>
            <a href="auth/register.php">Register</a>
        <?php else: ?>
            <a href="profile.php"><?= htmlspecialchars($username) ?></a>
            <a href="cart.php">Cart</a>
            <a href="transactions.php">History</a>
            <a href="logout.php" class="nav-danger">Logout</a>
        <?php endif; ?>
    </div>
</nav>

<div class="header">
    <h1>Product Catalog</h1>
    <p>Browse, filter, and sort furniture</p>
</div>

<form method="GET" class="filter-bar">
    <div class="filter-left">
        <select name="vendor">
            <option value="">All Vendors</option>
            <?php $vendors->data_seek(0); // Reset pointer ?>
            <?php while ($v = $vendors->fetch_assoc()): ?>
                <option value="<?= $v['VendorID'] ?>" <?= $vendorId == $v['VendorID'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($v['VendorName']) ?>
                </option>
            <?php endwhile; ?>
        </select>

        <select name="sort">
            <option value="">Sort by</option>
            <option value="name_asc" <?= $sort == 'name_asc' ? 'selected' : '' ?>>Name A–Z</option>
            <option value="name_desc" <?= $sort == 'name_desc' ? 'selected' : '' ?>>Name Z–A</option>
            <option value="price_asc" <?= $sort == 'price_asc' ? 'selected' : '' ?>>Price Low–High</option>
            <option value="price_desc" <?= $sort == 'price_desc' ? 'selected' : '' ?>>Price High–Low</option>
        </select>
    </div>

    <div class="filter-right">
        <input type="text" name="search" placeholder="Search product..." value="<?= htmlspecialchars($search) ?>">
        <button type="submit">Apply Filter</button>
    </div>
</form>

<main>
<?php if ($products->num_rows > 0): ?>
    <div class="grid">
    <?php while ($p = $products->fetch_assoc()): ?>
        <div class="card">
            <?php if ($p['Image']): ?>
                <img src="uploads/<?= htmlspecialchars($p['Image']) ?>" alt="<?= htmlspecialchars($p['ProductName']) ?>">
            <?php endif; ?>
            <h4><?= htmlspecialchars($p['ProductName']) ?></h4>
            <small><?= htmlspecialchars($p['VendorName']) ?></small>
            <div class="price">Rp <?= number_format($p['Price'],0,",",".") ?></div>
            <a href="product_detail.php?id=<?= $p['ProductID'] ?>" class="btn">View Detail</a>
        </div>
    <?php endwhile; ?>
    </div>
<?php else: ?>
    <div class="no-products-message">
        <p>No products found matching your filter criteria.</p>
    </div>
<?php endif; ?>
</main>

<footer>
    © 2025 Furniland. All rights reserved.<br>
    Contact: furniland-support@gmail.com
</footer>

</body>
</html>