<?php
require "config/db.php";
require "middleware/admin.php";

$sql = "SELECT t.TransactionID, t.TransactionDate, t.TotalPrice,
                u.Username
        FROM transactions t
        JOIN users u ON t.UserID = u.UserID
        ORDER BY t.TransactionDate DESC";
$result = $conn->query($sql);

$username = $_SESSION['username'] ?? 'Admin'; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Transactions - Furniland</title>
    <style>
        body {
            margin: 0;
            background-color: #0f1b2b;
            color: white;
            font-family: Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        
        nav {
            background-color: #14263d;
            padding: 14px 30px; 
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        
        .nav-group {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        
        .logo {
            font-weight: bold;
            font-size: 18px; 
            color: #e5f1ff !important; 
            text-decoration: none;
            margin-right: 10px;
        }
        .logo:hover {
            color: #00c8ff !important;
        }

        
        nav a {
            color: #d0e8ff;
            text-decoration: none;
            font-size: 14px;
            margin: 0;
            padding: 5px 0;
        }

        nav a:hover {
            color: #00c8ff;
        }
        
        
        .username-link {
            color: #4fd2ff !important;
        }
        .logout-link {
            color: #ff6b6b !important;
        }


        
        .container {
            flex: 1;
            padding: 40px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            max-width: 1000px;
            margin: auto;
            border-collapse: collapse;
            background-color: #14263d;
        }

        th {
            background-color: #1d3557;
            padding: 12px;
        }

        td {
            padding: 12px;
            border-top: 1px solid #35506b;
            text-align: center;
        }

        tr:hover {
            background-color: #1a2f47;
        }

        
        footer {
            background:#0d1826;
            color:#d0e8ff;
            text-align:center;
            padding:18px;
            font-size:14px;
            border-top:1px solid #23384d;
        }
    </style>
</head>
<body>

<nav>
    <div class="nav-group">
        <a href="home.php" class="logo">Furniland</a>
        <a href="home.php">Dashboard</a>
    </div>

    <div class="nav-group">
        <a class="username-link" href="profile.php">
            <?= htmlspecialchars($username) ?> (Admin)
        </a>
        <a href="logout.php" class="logout-link">Logout</a>
    </div>
</nav>

<div class="container">
    <h2>All Transactions</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>User</th>
            <th>Date</th>
            <th>Total</th>
        </tr>

        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['TransactionID'] ?></td>
                    <td><?= htmlspecialchars($row['Username']) ?></td>
                    <td><?= $row['TransactionDate'] ?></td>
                    <td>Rp <?= number_format($row['TotalPrice'], 0, ',', '.') ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
             <tr>
                <td colspan="4" style="text-align:center; opacity:.7; padding: 20px;">
                    No transactions found.
                </td>
            </tr>
        <?php endif; ?>
    </table>
</div>

<footer>
    © 2025 Furniland. All rights reserved.<br>
    Contact: furniland-support@gmail.com
</footer>

</body>
</html>