<?php
require "config/db.php";
require "middleware/member.php";

$userId = $_SESSION['user_id'];

$sql = "SELECT c.CartID, c.ProductID, c.Quantity, p.Price
        FROM cart c
        JOIN products p ON c.ProductID = p.ProductID
        WHERE c.UserID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$cartItems = $stmt->get_result();

if ($cartItems->num_rows === 0) {
    header("Location: cart.php");
    exit();
}

$total = 0;
$items = [];
while ($row = $cartItems->fetch_assoc()) {
    $subtotal = $row['Quantity'] * $row['Price'];
    $total += $subtotal;
    $items[] = [
        'product_id' => $row['ProductID'],
        'qty' => $row['Quantity'],
        'subtotal' => $subtotal
    ];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Processing Checkout...</title>

    <style>
        body {
            margin: 0;
            background-color: #0f1b2b;
            color: white;
            font-family: Arial, sans-serif;
            text-align: center;
            padding-top: 60px;
        }

        nav {
            background-color: #14263d;
            padding: 15px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: fixed;
            top: 0;
            width: 100%;
        }

        .nav-left a, .nav-right a {
            color: #d0e8ff;
            margin-left: 15px;
            text-decoration: none;
            font-size: 14px;
        }

        .logo-text {
            font-size: 20px;
            font-weight: bold;
            color: white;
            margin-right: 30px;
        }

        nav a:hover {
            color: #00c8ff;
        }

        .loading-box {
            margin-top: 100px;
            font-size: 20px;
            opacity: 0.85;
        }
    </style>

</head>
<body>


<nav>
    <div class="nav-left">
        <span class="logo-text">Furniland</span>
        <a href="home.php">Home</a>
        <a href="catalog.php">Catalog</a>
    </div>

    <div class="nav-right">
        <a href="profile.php"><?= htmlspecialchars($_SESSION['username']) ?></a>
        <a href="cart.php">Cart</a>
        <a href="transactions.php">History</a>
        <a href="logout.php" style="color:#ff6b6b;">Logout</a>
    </div>
</nav>

<div class="loading-box">
    Processing your checkout...
</div>

</body>
</html>
<?php


$conn->begin_transaction();
try {
    
    $sql = "INSERT INTO transactions (UserID, TotalPrice)
            VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $userId, $total);
    $stmt->execute();
    $transactionId = $stmt->insert_id;

    
    $sqlDetail = "INSERT INTO transactiondetails
                  (TransactionID, ProductID, Quantity, Subtotal)
                  VALUES (?, ?, ?, ?)";
    $stmtDetail = $conn->prepare($sqlDetail);

    foreach ($items as $it) {
        $stmtDetail->bind_param(
            "iiii",
            $transactionId,
            $it['product_id'],
            $it['qty'],
            $it['subtotal']
        );
        $stmtDetail->execute();
    }

    
    $sql = "DELETE FROM cart WHERE UserID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();

    $conn->commit();

    header("refresh:1; url=transactions.php"); 
    exit();

} catch (Exception $e) {
    $conn->rollback();
    echo "<p style='color:red;'>Checkout failed.</p>";
}
?>
