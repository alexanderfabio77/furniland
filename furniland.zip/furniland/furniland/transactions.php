<?php
require "config/db.php";
require "middleware/member.php";

$userId   = $_SESSION['user_id'];
$username = $_SESSION['username'];

$sql = "SELECT * FROM transactions
        WHERE UserID = ?
        ORDER BY TransactionDate DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$transactions = $stmt->get_result();

function getTransactionItems($conn, $transactionId) {
    $sql = "SELECT td.Quantity, td.Subtotal, p.ProductName
            FROM transactiondetails td
            JOIN products p ON td.ProductID = p.ProductID
            WHERE td.TransactionID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $transactionId);
    $stmt->execute();
    return $stmt->get_result();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Transaction History - Furniland</title>

    <style>
        body {
            margin: 0;
            background:linear-gradient(#0f1b2b,#0b1522);
            color: white;
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        main {
            flex: 1;
        }

        
        /* --- SINKRONISASI NAV BAR --- */
        nav {
            background-color: #14263d;
            padding: 14px 30px; /* Disinkronkan */
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .nav-group {
            display: flex;
            align-items: center;
            gap: 15px; 
        }
        .logo-text {
            font-size: 20px; /* Disinkronkan */
            font-weight: bold;
            color: #e5f1ff !important;
            text-decoration: none;
            margin-right: 10px;
        }
        nav a {
            color: #d0e8ff;
            text-decoration: none;
            font-size: 14px;
            margin: 0;
            padding: 5px 0; /* Disinkronkan */
        }
        nav a:hover {
            color: #00c8ff;
        }
        
        /* CLASS AKTIF & DANGER (Menggantikan .current-page dan .logout) */
        .nav-active {
            color: #4fd2ff !important; 
            font-weight: bold;
        }
        .nav-danger { 
            color:#ff6b6b !important; 
        }
        /* --------------------------- */


        .page-title {
            margin: 40px 0 30px;
            text-align: center;
            font-size: 36px;
            color: #e5f1ff;
        }

        
        .transaction-list {
            width: 90%;
            max-width: 900px;
            margin: 0 auto 50px;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .transaction-box {
            background-color: #122030; 
            border: 1px solid #1f3a50;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: transform 0.2s;
        }

        .transaction-box:hover {
            transform: translateY(-2px);
            border-color: #35506b;
        }

        .transaction-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #1f3a50;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        .transaction-id {
            font-size: 18px;
            font-weight: bold;
            color: #4fd2ff; 
        }
        
        .transaction-date {
            font-size: 13px;
            color: #9bb4cc;
        }
        
        .transaction-total {
            font-size: 22px;
            font-weight: bold;
            color: #4ade80; 
            margin-top: 5px;
            margin-bottom: 15px;
            text-align: right;
        }

        .item-list-title {
            font-weight: bold;
            font-size: 15px;
            color: #c7d8f2;
            margin-bottom: 8px;
            display: block;
        }

        ul {
            list-style: none; 
            margin-top: 0;
            padding-left: 0;
        }

        li {
            margin-bottom: 8px;
            padding: 8px 10px;
            background: #0f1b2b; 
            border-radius: 4px;
            display: flex;
            justify-content: space-between;
            font-size: 14px;
        }
        
        .item-details span {
            margin-left: 15px;
            color: #9bb4cc;
        }
        .item-details strong {
            color: #e5f1ff;
        }

        
        .empty-state {
            text-align: center;
            opacity: 0.8;
            padding: 40px;
            font-size: 16px;
            background: #122030;
            border-radius: 8px;
            border: 1px solid #1f3a50;
            width: 90%;
            max-width: 900px;
            margin: 30px auto;
        }

        
        footer {
            background:#0d1826;
            color:#d0e8ff;
            text-align:center;
            padding:18px;
            font-size:14px;
            border-top:1px solid #23384d;
            margin-top:auto;
        }
    </style>
</head>
<body>

<nav>
    <div class="nav-group">
        <a href="home.php" class="logo-text">Furniland</a>
        <a href="home.php">Home</a>
        <a href="catalog.php">Catalog</a>
    </div>

    <div class="nav-group">
        <a href="profile.php"><?= htmlspecialchars($username) ?></a>
        <a href="cart.php">Cart</a>
        <a href="transactions.php" class="nav-active">History</a>
        <a href="logout.php" class="nav-danger">Logout</a>
    </div>
</nav>

<main>
<h2 class="page-title">Transaction History</h2>

<?php if ($transactions->num_rows === 0): ?>
    <div class="empty-state">
        <p>You have no transaction history yet. Purchase something from our <a href="catalog.php" style="color: #4fd2ff;">Catalog</a>!</p>
    </div>

<?php else: ?>
    <div class="transaction-list">
    <?php while ($t = $transactions->fetch_assoc()): ?>
        <div class="transaction-box">

            <div class="transaction-header">
                <div class="transaction-id">
                    #<?= $t['TransactionID'] ?>
                </div>
                <div class="transaction-date">
                    Date: <?= date('d M Y, H:i', strtotime($t['TransactionDate'])) ?> WIB
                </div>
            </div>
            
            <div class="transaction-total">
                Total: Rp <?= number_format($t['TotalPrice'], 0, ',', '.') ?>
            </div>

            <span class="item-list-title">Purchased Items:</span>
            <ul>
                <?php
                $items = getTransactionItems($conn, $t['TransactionID']);
                while ($it = $items->fetch_assoc()):
                ?>
                    <li>
                        <div class="item-details">
                            <strong><?= htmlspecialchars($it['ProductName']) ?></strong>
                            <span>(Qty: <?= $it['Quantity'] ?>)</span>
                        </div>
                        <div class="item-subtotal">
                            Rp <?= number_format($it['Subtotal'], 0, ',', '.') ?>
                        </div>
                    </li>
                <?php endwhile; ?>
            </ul>

        </div>
    <?php endwhile; ?>
    </div>
<?php endif; ?>
</main>

<footer>
    © 2025 Furniland. All rights reserved.<br>
    Contact: furniland-support@gmail.com
</footer>

</body>
</html>