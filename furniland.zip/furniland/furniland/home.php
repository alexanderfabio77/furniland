<?php
require "config/db.php";
session_start();

$role     = $_SESSION['role']     ?? 'Guest';
$username = $_SESSION['username'] ?? null;
$result   = null;


if ($role !== 'Admin') {
    
    $sql = "SELECT p.ProductID, p.ProductName, p.Price, p.Image, v.VendorName
            FROM products p
            JOIN vendors v ON p.VendorID = v.VendorID
            ORDER BY RAND()
            LIMIT 6";
    $result = $conn->query($sql);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Furniland</title>

<style>

body{
    margin:0;
    /* Background konsisten */
    background:linear-gradient(#0f1b2b,#0b1522);
    color:#fff;
    font-family:Arial, sans-serif;
    min-height:100vh;
    display:flex;
    flex-direction:column;
}
main{flex:1}


nav{
    background:#14263d; 
    padding:14px 30px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.nav-group {
    display: flex;
    align-items: center;
    gap: 15px; 
}


nav a{
    color:#d0e8ff; 
    text-decoration:none;
    font-size:14px;
    margin: 0; 
    padding: 5px 0; 
}
nav a:hover{color:#00c8ff}


.logo{
    font-weight:bold;
    font-size:18px;
    color: #e5f1ff !important; 
    text-decoration: none;
    margin-right: 10px; 
}
.logo:hover {
    color: #00c8ff !important;
}


.admin-container{
    max-width:1200px;
    margin:auto;
    padding:40px 40px 20px;
}
.admin-title{
    font-size:28px;
    margin-bottom:25px;
}
.admin-cards{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:20px;
}
.admin-card{
    background:#143c5a;
    border:1px solid #1f4f73;
    border-radius:6px;
    padding:16px;
    cursor:pointer;
    transition:.2s;
}
.admin-card:hover{
    background:#1d4e72;
    transform:translateY(-3px);
}
.admin-card h3{
    margin:0 0 6px;
    font-size:14px;
}
.admin-card p{
    margin:0;
    font-size:12px;
    color:#c7d8f2;
}

.admin-welcome{
    margin-top:20px;
    background:#0f2c42;
    border:1px solid #1f4f73;
    border-radius:6px;
    padding:18px 20px;
    font-size:13px;
}


.hero{
    text-align:center;
    padding:60px 20px 30px;
}
.hero h1{
    font-size:40px;
    margin-bottom:6px;
}
.hero p{
    font-size:16px;
    color:#7f9abf;
    font-weight: normal;
}

/* ... CSS Lainnya ... */

.products{
    max-width:1400px;
    margin:0 auto 50px;
    padding:30px 40px 50px;
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); /* Lebar min dinaikkan sedikit untuk estetika */
    gap:25px; /* Gap sedikit dilebarkan */
}


.product-card{
    background: #0d1721; 
    border: none;
    border-radius: 8px; 
    padding: 15px;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    cursor: default;
    
    /* === PERUBAHAN UTAMA UNTUK KETINGGIAN SAMA === */
    display: flex;
    flex-direction: column;
    /* =========================================== */
}
.product-card:hover{
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
}
.product-card img{
    width: 100%;
    height: 200px; 
    object-fit: cover;
    border-radius: 4px;
    margin-bottom: 12px;
}

.product-name{
    font-size: 18px;
    font-weight: 500;
    color: #eaf2f8;
    margin: 0 0 4px 0;
}

.product-vendor{
    font-size: 14px;
    color: #7f9abf;
    line-height: 1.4;
    margin: 0 0 15px 0;
    
    /* === PERUBAHAN UTAMA: HAPUS FIXED HEIGHT DAN OVERFLOW === */
    /* height: 65px; */
    /* overflow: hidden; */ 
    /* ======================================================== */
    
    /* Flex-grow agar elemen ini mengambil sisa ruang vertikal */
    flex-grow: 1;
}

.product-price{
    font-size: 20px;
    color: #38c6ff;
    font-weight: bold;
    margin-bottom: 15px;
}

.btn{
    display: block;
    background: #0088cc;
    color: #ffffff;
    padding: 10px 10px;
    font-size: 15px;
    border-radius: 4px;
    text-decoration: none;
    text-align: center;
    font-weight: bold;
    transition: background 0.2s;
    margin-top: auto; 
}
.btn:hover{
    background: #00aaff;
}

/* FOOTER */
footer{
    text-align:center;
    padding:22px;
    font-size:13px;
    color:#9bb4cc;
    border-top:1px solid #23384d;
}
</style>
</head>

<body>

<nav>
    <div class="nav-group">
        <a href="home.php" class="logo">Furniland</a>
        <?php if ($role === 'Admin'): ?>
            <a href="home.php">Dashboard</a>
        <?php else: ?>
            <a href="home.php">Home</a>
        <?php endif; ?>

        
        <?php 
        
        if ($role === 'Member'): 
        ?>
            <a href="catalog.php">Catalog</a>
        <?php endif; ?>
    </div>
    
    <div class="nav-group">
        <?php if ($role === 'Guest'): ?>
            <a href="auth/login.php" style="color: #4fd2ff;">Login</a>
        <?php elseif ($role === 'Member'): ?>
            <a href="profile.php"><?= htmlspecialchars($username) ?></a>
            <a href="cart.php">Cart</a>
            <a href="transactions.php">History</a> 
            <a href="logout.php" style="color:#ff6b6b">Logout</a>
        <?php else: ?>
            <a href="profile.php" style="color: #4fd2ff;"><?= htmlspecialchars($username) ?> (Admin)</a>
            <a href="logout.php" style="color:#ff6b6b">Logout</a>
        <?php endif; ?>
    </div>
</nav>

<main>
<?php if ($role === 'Admin'): ?>

    <div class="admin-container">
        <div class="admin-title">Admin Dashboard</div>
        <div class="admin-cards">
            <div class="admin-card" onclick="location.href='products/index.php'">
                <h3>Manage Products</h3>
                <p>View, edit, and add furniture products.</p>
            </div>
            <div class="admin-card" onclick="location.href='vendors/index.php'">
                <h3>Manage Vendors</h3>
                <p>View and manage furniture vendors.</p>
            </div>
            <div class="admin-card" onclick="location.href='users/index.php'">
                <h3>Manage Users</h3>
                <p>View and control user accounts.</p>
            </div>
            <div class="admin-card" onclick="location.href='admin_transactions.php'">
                <h3>View Transactions</h3>
                <p>Monitor purchase history and details.</p>
            </div>
        </div>
        <div class="admin-welcome">
            <strong>Welcome, Admin <?= htmlspecialchars($username) ?>!</strong><br>
            Use the cards above to manage the platform. Keep track of users,
            inventory, vendors, and transactions efficiently.
        </div>
    </div>

<?php else: ?>

    <div class="hero">
        <h1>Furniland</h1>
        <p>Furniture you might like</p>
    </div>

    <section class="products">
        <?php 
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()): ?>
                <div class="product-card">
                    <img src="uploads/<?= htmlspecialchars($row['Image']) ?>">
                    <div class="product-name"><?= htmlspecialchars($row['ProductName']) ?></div>
                    <div class="product-vendor"><?= htmlspecialchars($row['VendorName']) ?></div> 
                    <div class="product-price">
                        Rp <?= number_format($row['Price'],0,',','.') ?>
                    </div>
                    <a class="btn" href="product_detail.php?id=<?= $row['ProductID'] ?>">
                        View Details
                    </a>
                </div>
            <?php endwhile;
        } else {
            echo "<p style='text-align:center; width:100%; margin-top:20px; color:#7f9abf;'>No featured products available at the moment.</p>";
        }
        ?>
    </section>

<?php endif; ?>
</main>

<footer>
    © 2025 Furniland. All rights reserved<br>
    Contact us at furniland@example.com
</footer>

</body>
</html>