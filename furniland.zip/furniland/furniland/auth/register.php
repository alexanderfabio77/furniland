<?php
require "../config/db.php";
session_start();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';
    $gender   = $_POST['gender'] ?? '';
    $dob      = $_POST['dob'] ?? '';

    
    if ($username === '' || strlen($username) < 4 || strlen($username) > 20) {
        $errors[] = "Username harus 4 - 20 karakter.";
    }
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/@gmail\.com$/i', $email)) {
        $errors[] = "Email harus valid dan berakhiran @gmail.com.";
    }
    if ($password === '' || strlen($password) < 8) {
        $errors[] = "Password minimal 8 karakter.";
    }
    if ($password !== $confirm) {
        $errors[] = "Konfirmasi password tidak cocok.";
    }
    if ($gender !== 'Male' && $gender !== 'Female') {
        $errors[] = "Gender harus dipilih.";
    }
    if ($dob === '') {
        $errors[] = "Tanggal lahir harus diisi.";
    } else {
        $d = DateTime::createFromFormat('Y-m-d', $dob);
        $now = new DateTime();
        if (!$d || $d > $now) {
            $errors[] = "Tanggal lahir harus tanggal valid di masa lalu.";
        }
    }

    
    if (empty($errors)) {
        $sql = "SELECT UserID FROM users WHERE Username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $errors[] = "Username sudah digunakan.";
        }
        $stmt->close();

        $sql = "SELECT UserID FROM users WHERE Email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $errors[] = "Email sudah terdaftar.";
        }
        $stmt->close();
    }

    
    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO users (Username, Email, Password, Gender, DOB, Role)
                VALUES (?, ?, ?, ?, ?, 'Member')";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $username, $email, $hash, $gender, $dob);

        if ($stmt->execute()) {
            
            $userID = $stmt->insert_id;

            $_SESSION['user_id']  = $userID;
            $_SESSION['username'] = $username;
            $_SESSION['role']     = "Member";
            
            
            header("Location: ../home.php"); 
            exit();
        } else {
            $errors[] = "Gagal register: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Register - Furniland</title>
    
    <style>
        
        body{
            margin:0;
            min-height:100vh;
            background:linear-gradient(180deg,#0e1a29 0%,#0b1522 100%);
            font-family:Arial, sans-serif;
            color:#fff;
            display:flex;
            flex-direction:column;
        }

        /* ========== NAV SECTION (Revisi Seragam) ========== */
        nav{
            background:#14263d; /* Warna dari home.php */
            padding:14px 30px; /* Padding dari home.php */
            display:flex;
            justify-content:space-between;
            align-items:center;
        }
        .nav-group { /* Class dari home.php */
            display: flex;
            align-items: center;
            gap: 15px; 
        }
        .logo{
            font-weight:bold;
            font-size:18px; /* Ukuran font dari home.php */
            color: #e5f1ff !important; 
            text-decoration: none;
            margin-right: 10px; 
        }
        .logo:hover {
            color: #00c8ff !important;
        }
        nav a{
            color:#d0e8ff; /* Warna default link dari home.php */
            text-decoration:none;
            font-size:14px;
            margin: 0; 
            padding: 5px 0; 
        }
        nav a:hover{color:#00c8ff}
        /* ================================================= */
        
        /* Perubahan di sini untuk menambah gap */
        .main{
            flex:1;
            display:flex;
            justify-content:center;
            align-items:center;
            padding: 40px 0; /* BARU: Memberi jarak (gap) di atas dan bawah */
        }

        
        .register-box{
            width:380px;
            background:#0f1c2b;
            border:1px solid #1a2c40;
            border-radius:8px;
            padding:30px 40px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.4); 
        }
        .register-title{
            text-align:center;
            font-size:24px; 
            margin-bottom:22px;
            color:#e5f1ff;
            font-weight: bold;
        }

    
        .form-group{
            margin-bottom:18px;
        }
        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="password"],
        .form-group input[type="date"],
        .form-group select {
            width:100%;
            padding:12px 15px;
            background:#0c1522;
            border:1px solid #1a2c40;
            border-radius:4px;
            color:#fff;
            font-size:15px;
            box-sizing: border-box; 
        }
        .form-group input:focus,
        .form-group select:focus {
            outline:none;
            border-color:#0088cc;
        }
        
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-size: 14px;
            color: #c7d8f2;
        }
        
      
        .gender-group {
            margin-top: 5px;
            display: flex;
            gap: 20px;
            font-size: 14px;
            color: #c7d8f2;
            align-items: center;
        }
        .gender-group label {
            display: inline;
            margin-right: 5px;
        }

    
        button{
            width:100%;
            background:#0088cc;
            border:none;
            color:#fff;
            padding:12px;
            border-radius:4px;
            font-size:16px;
            cursor:pointer;
            font-weight:bold;
            margin-top: 10px; 
            transition: background 0.2s; 
        }
        button:hover{background:#00aaff}

        
        .error-list {
            list-style-type: none;
            padding: 8px 15px;
            margin: 0 0 18px 0;
            background:#401a1a;
            border:1px solid #7a2a2a;
            color:#ffb4b4;
            font-size:13px;
            border-radius:4px;
            text-align: left;
        }

      
        .login-link{
            margin-top:18px;
            text-align:center;
            font-size:14px;
            color:#c7d8f2;
        }
        .login-link a{
            color:#0088cc;
            text-decoration:none;
            font-weight:bold;
        }
        .login-link a:hover {
            text-decoration: underline; 
        }

        /* FOOTER */
        footer{
            text-align:center;
            padding:18px;
            font-size:12px;
            color:#7f9abf;
            border-top: 1px solid #1a2c40; 
        }
    </style>
</head>

<body>
<nav>
    <div class="nav-group">
        <a href="../home.php" class="logo">
            Furniland
        </a>
        <a href="../home.php">Home</a>
    </div>
    <div class="nav-group">
        <a href="login.php">Login</a>
    </div>
</nav>

<div class="main">
    <div class="register-box">
        <div class="register-title">Register</div>

        <?php if (!empty($errors)): ?>
            <ul class="error-list">
                <?php foreach ($errors as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <input type="text" name="username" placeholder="Username"
                        value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                        required>
            </div>

            <div class="form-group">
                <input type="email" name="email" placeholder="Email (@gmail.com)"
                        value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                        required>
            </div>

            <div class="form-group">
                <input type="password" name="password" placeholder="Password (min 8 chars)" required>
            </div>

            <div class="form-group">
                <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            </div>

            <div class="form-group">
                <label style="display:inline; color:#c7d8f2;">Gender</label>
                <div class="gender-group" style="margin-top: 5px;">
                    <input type="radio" name="gender" value="Male" id="male"
                            <?= (($_POST['gender'] ?? '') === 'Male') ? 'checked' : '' ?> required>
                    <label for="male">Male</label>

                    <input type="radio" name="gender" value="Female" id="female"
                            <?= (($_POST['gender'] ?? '') === 'Female') ? 'checked' : '' ?> required>
                    <label for="female">Female</label>
                </div>
            </div>

            <div class="form-group">
                <label for="dob">Date of Birth</label>
                <input type="date" name="dob" id="dob"
                        value="<?= htmlspecialchars($_POST['dob'] ?? '') ?>"
                        required>
            </div>

            <button type="submit">Register</button>
        </form>

        <div class="login-link">
            Already have an account?
            <a href="login.php">Login here</a>
        </div>
    </div>
</div>

<footer>
    © 2025 Furniland. All rights reserved.<br>
    Contact: furniland.support@gmail.com
</footer>

</body>
</html>