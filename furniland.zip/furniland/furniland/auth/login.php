<?php
require "../config/db.php";
session_start();

$error = "";
$post_email = ""; 


if (isset($_SESSION['user_id'])) {
    header("Location: ../home.php");
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email      = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);

    
    $post_email = htmlspecialchars($email); 

    if ($email === '' || $password === '') {
        $error = "Email dan password harus diisi.";
    } else {
        $stmt = $conn->prepare(
            "SELECT UserID, Username, Role, Password FROM users WHERE Email = ?"
        );
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows === 1) {
            $user = $res->fetch_assoc();

            if (password_verify($password, $user['Password'])) {
                $_SESSION['user_id']  = $user['UserID'];
                $_SESSION['username'] = $user['Username'];
                $_SESSION['role']     = $user['Role'];

                if ($remember) {
                    setcookie(
                        "user_id",
                        $user['UserID'],
                        time() + 7 * 24 * 60 * 60,
                        "/"
                    );
                }

                header("Location: ../home.php");
                exit();
            } else {
                $error = "Password salah.";
            }
        } else {
            $error = "Email tidak terdaftar.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Login - Furniland</title>

<style>
body{
    margin:0;
    min-height:100vh;
    
    background:linear-gradient(180deg,#0b1522 0%,#080f18 100%);
    font-family:Arial, sans-serif;
    color:#fff;
    display:flex;
    flex-direction:column;
}

/* ========== NAV SECTION (Revisi Seragam) ========== */
nav{
    background:#14263d; /* Warna dari home.php */
    padding:14px 30px; /* Padding dari home.php */
    display:flex;
    justify-content:space-between;
    align-items:center;
}
.nav-group { /* Class dari home.php */
    display: flex;
    align-items: center;
    gap: 15px; 
}
.logo{
    font-weight:bold;
    font-size:18px; /* Ukuran font dari home.php */
    color: #e5f1ff !important; 
    text-decoration: none;
    margin-right: 10px; 
}
.logo:hover {
    color: #00c8ff !important;
}
nav a{
    color:#d0e8ff; /* Warna default link dari home.php */
    text-decoration:none;
    font-size:14px;
    margin: 0; 
    padding: 5px 0; 
}
nav a:hover{color:#00c8ff}
/* Hapus .nav-left dari CSS */
/* ================================================= */

.main{
    flex:1;
    display:flex;
    justify-content:center;
    align-items:center;
    padding: 40px 0; /* BARU: Memberi jarak (gap) di atas dan bawah */
}


.login-box{
    width:380px;
    
    background:#122030;
    border:1px solid #1f3a50;
    border-radius:8px;
    padding:35px 45px; 
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.4);
}
.login-title{
    text-align:center;
    font-size:24px;
    margin-bottom:30px; 
    color:#e5f1ff;
    font-weight: bold;
}


.form-group{
    margin-bottom:18px;
}
.form-group input{
    width:100%;
    padding:12px 15px;
 
    background:#0f1b2b; 
    border:1px solid #35506b; 
    border-radius:4px;
    color:#fff;
    font-size:15px;
    box-sizing: border-box; 
}
.form-group input:focus{
    outline:none;
    border-color:#0088cc; 
}


.remember{
    display:flex;
    align-items:center;
    gap:8px;
    font-size:14px;
    color:#c7d8f2;
    margin-bottom:25px;
}
.remember input[type="checkbox"] {
    width: auto; 
}

button{
    width:100%;
    
    background:#0088cc;
    border:none;
    color:#fff;
    padding:12px;
    border-radius:4px;
    font-size:16px;
    cursor:pointer;
    font-weight:bold;
    transition: background 0.2s;
}
button:hover{background:#00aaff}


.error{
    background:rgba(122, 42, 42, 0.3); 
    border:1px solid #ff6b6b; 
    color:#ffb4b4;
    padding:10px;
    font-size:14px;
    border-radius:4px;
    margin-bottom:20px;
    text-align:center;
}


.register{
    margin-top:25px;
    text-align:center;
    font-size:14px;
    color:#c7d8f2;
}
.register a{
    color:#4fd2ff; 
    text-decoration:none;
    font-weight:bold;
}
.register a:hover {
    text-decoration: underline;
}


footer{
    text-align:center;
    padding:18px;
    font-size:12px;
    color:#7f9abf;
    border-top: 1px solid #1a2c40;
}
</style>
</head>

<body>

<nav>
    <div class="nav-group">
        <a href="../home.php" class="logo">
            Furniland
        </a>
        <a href="../home.php">Home</a>
    </div>
    <div class="nav-group">
        <a href="login.php">Login</a>
    </div>
</nav>

<div class="main">
    <div class="login-box">
        <div class="login-title">Sign in to Furniland</div>

        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <input type="email" name="email" placeholder="Email Address" 
                        value="<?= $post_email ?>" required>
            </div>

            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>

            <div class="remember">
                <input type="checkbox" name="remember" id="remember_me">
                <label for="remember_me">Remember me</label>
            </div>

            <button type="submit">Login</button>
        </form>

        <div class="register">
            Don’t have an account?
            <a href="register.php">Register here</a>
        </div>
    </div>
</div>

<footer>
    © 2025 Furniland. All rights reserved.<br>
    Contact: furniland.support@gmail.com
</footer>

</body>
</html>