<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: /furniland/auth/login.php");
    exit;
}

if ($_SESSION['role'] !== 'Member' && $_SESSION['role'] !== 'Admin') {
    header("Location: /furniland/home.php");
    exit;
}
