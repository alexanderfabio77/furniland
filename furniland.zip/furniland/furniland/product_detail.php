<?php
require "config/db.php";
session_start();

$role     = $_SESSION['role']     ?? 'Guest';
$username = $_SESSION['username'] ?? null;

if (!isset($_GET['id'])) {
    header("Location: catalog.php");
    exit;
}

$productId = (int) $_GET['id'];


$sql = "SELECT p.*, v.VendorName, v.VendorLocation, p.Description
        FROM products p
        JOIN vendors v ON p.VendorID = v.VendorID
        WHERE p.ProductID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $productId);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();

if (!$product) {
    header("Location: catalog.php");
    exit;
}


$description_to_display = $product['Description'] ?? ''; 
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title><?= htmlspecialchars($product['ProductName']) ?> - Furniland</title>

<style>

body {
    margin: 0;
    background: linear-gradient(#0f1b2b, #0b1522);
    color: white;
    font-family: Arial, sans-serif;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}
main {
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    padding: 60px 40px;
}


nav {
    background:#14263d;
    padding:14px 30px; 
    display:flex;
    justify-content:space-between;
    align-items:center;
}
.nav-group {
    display: flex;
    align-items: center;
    gap: 15px;
}
.logo {
    font-weight:bold;
    font-size:18px; 
    color: #e5f1ff !important;
    text-decoration: none;
    margin-right: 10px;
}
.logo:hover { color:#00c8ff !important; }

nav a {
    color:#d0e8ff;
    text-decoration:none;
    font-size:14px;
    margin: 0;
    padding: 5px 0;
}
nav a:hover { color:#00c8ff; }
.logout { color:#ff6b6b !important; }
.username-link { color: #4fd2ff !important; } 



.product-wrapper {
    display: flex;
    gap: 60px;
    max-width: 900px;
    width: 100%;
    background: #122030; 
    padding: 30px;
    border-radius: 10px;
    border: 1px solid #1f3a50;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}


.product-image {
    flex-shrink: 0;
    width: 320px;
}
.product-image img {
    width: 100%;
    height: auto;
    border-radius: 6px;
    background: #203445;
    display: block;
}


.product-info {
    flex-grow: 1;
}
.product-info h1 {
    margin: 0 0 6px;
    font-size: 28px; 
    color: #e5f1ff;
}

.product-info p.desc:empty:before {
    content: "No detailed description available.";
    color: #8c9fae;
    font-style: italic;
    display: block;
}
.product-info p.desc {
    margin: 0 0 20px;
    color: #b0c6d9; 
    font-size: 14px;
    line-height: 1.6;
}
.price {
    font-size: 24px; 
    font-weight: bold;
    color: #4ade80; 
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #1f3a50;
}

.meta {
    font-size: 14px;
    color: #d0e8ff;
    margin-bottom: 10px;
}

.qty-box {
    margin: 25px 0 25px;
    font-size: 14px;
    font-weight: bold;
    color: #c7d8f2;
}
.qty-box input {
    width: 60px;
    padding: 8px; 
    margin-left: 10px;
    background:#0f1b2b;
    border:1px solid #35506b;
    color:white;
    border-radius:4px;
    text-align: center;
}
.qty-box input:focus {
    outline: none;
    border-color: #0088cc;
}

/* BUTTON */
.btn-add {
    display: inline-block;
    width: 250px; 
    padding: 12px;
    background: #1abc9c;
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 16px; 
    font-weight: bold;
    cursor: pointer;
    transition: background 0.2s;
}
.btn-add:hover {
    background:#17a589;
}

/* ===== FOOTER ===== */
footer {
    background:#0d1826;
    border-top:1px solid #23384d;
    text-align:center;
    padding:18px; 
    color:#9bb4cc;
    font-size:13px;
    margin-top: auto;
}
</style>
</head>
<body>

<nav>
    <div class="nav-group">
        <a href="home.php" class="logo">Furniland</a>
        <a href="home.php">Home</a>
        <a href="catalog.php">Catalog</a>
    </div>
    <div class="nav-group">
        <?php if ($role === 'Guest'): ?>
            <a href="auth/login.php">Login</a>
        <?php else: ?>
            <a href="profile.php" class="username-link"><?= htmlspecialchars($username) ?></a>
            <a href="cart.php">Cart</a>
            <a href="transactions.php">History</a>
            <a href="logout.php" class="logout">Logout</a>
        <?php endif; ?>
    </div>
</nav>

<main>
    <div class="product-wrapper">

        <div class="product-image">
            <?php $image_path = "uploads/" . htmlspecialchars($product['Image']); ?>
            <img 
                src="<?= $image_path ?>" 
                alt="<?= htmlspecialchars($product['ProductName']) ?>"
                onerror="this.onerror=null; this.src='assets/default_furniture.jpg';"
            >
        </div>

        <div class="product-info">
            <h1><?= htmlspecialchars($product['ProductName']) ?></h1>
            <p class="desc"><?= nl2br(htmlspecialchars($description_to_display)) ?></p>

            <div class="price">
                Rp <?= number_format($product['Price'], 0, ',', '.') ?>
            </div>

            <div class="meta">Vendor: **<?= htmlspecialchars($product['VendorName']) ?>**</div>
            <div class="meta">Location: **<?= htmlspecialchars($product['VendorLocation']) ?>**</div>

            <form method="POST" action="add_to_cart.php">
                <input type="hidden" name="product_id" value="<?= $productId ?>">

                <div class="qty-box">
                    Quantity:
                    <input type="number" name="qty" value="1" min="1" required>
                </div>

                <?php if ($role === 'Guest'): ?>
                    <button type="button" class="btn-add"
                        onclick="location.href='auth/login.php'">
                        Login to Add to Cart
                    </button>
                <?php else: ?>
                    <button type="submit" class="btn-add">
                        Add to Cart
                    </button>
                <?php endif; ?>
            </form>
        </div>

    </div>
</main>

<footer>
    © 2025 Furniland. All rights reserved.<br>
    Contact: furniland-support@gmail.com
</footer>

</body>
</html>