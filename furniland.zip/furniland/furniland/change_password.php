<?php
require "config/db.php";
require "middleware/auth.php";

$userId = $_SESSION['user_id'];
$errors = [];
$success = "";


if (isset($_POST['update_password'])) {

    $current = $_POST['current'] ?? '';
    $new     = $_POST['new'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    
    $sql = "SELECT Password FROM users WHERE UserID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    
    if (!password_verify($current, $user['Password'])) {
        $errors[] = "Current password salah.";
    }
    if (strlen($new) < 8) {
        $errors[] = "New password minimal 8 karakter.";
    }
    if ($new !== $confirm) {
        $errors[] = "Confirm password tidak cocok.";
    }

    
    if (empty($errors)) {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        $sql = "UPDATE users SET Password = ? WHERE UserID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $hash, $userId);
        $stmt->execute();
        $success = "Password berhasil diubah.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Change Password</title>

    <style>
        body {
            margin: 0;
            background-color: #0f1b2b;
            color: white;
            font-family: Arial, sans-serif;
        }

        nav {
            background-color: #14263d;
            padding: 15px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .logo-text {
            font-size: 20px;
            font-weight: bold;
            margin-right: 30px;
        }

        nav a {
            color: #d0e8ff;
            margin-left: 15px;
            text-decoration: none;
            font-size: 14px;
        }

        nav a:hover {
            color: #00c8ff;
        }

        .container {
            width: 45%;
            margin: 40px auto;
            background-color: #14263d;
            padding: 25px;
            border-radius: 8px;
            border: 1px solid #35506b;
        }

        input {
            width: 260px;
            padding: 7px;
            border-radius: 4px;
            border: none;
        }

        button {
            padding: 8px 16px;
            margin-top: 15px;
            background-color: #1abc9c;
            color: white;
            border: none;
            border-radius: 6px;
        }

        button:hover {
            background-color: #17a589;
        }

        .link-back {
            color: #4fd2ff;
            text-decoration: none;
        }

        .link-back:hover {
            color: #00c8ff;
        }
    </style>

</head>
<body>


<nav>
    <div>
        <span class="logo-text">Furniland</span>
        <a href="home.php">Home</a>
        <a href="catalog.php">Catalog</a>
    </div>

    <div>
        <a href="profile.php"><?= htmlspecialchars($_SESSION['username']) ?></a>
        <a href="cart.php">Cart</a>
        <a href="transactions.php">History</a>
        <a href="logout.php" style="color:#ff6b6b;">Logout</a>
    </div>
</nav>

<div class="container">
    <h2>Change Password</h2>

    <?php if ($success): ?>
        <p style="color:#58ff9c;"><?= htmlspecialchars($success) ?></p>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
        <ul style="color:#ff6b6b;">
            <?php foreach ($errors as $e): ?>
                <li><?= htmlspecialchars($e) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <form method="POST">
        <input type="hidden" name="update_password" value="1">

        <label>Current Password</label><br>
        <input type="password" name="current" required><br><br>

        <label>New Password</label><br>
        <input type="password" name="new" required><br><br>

        <label>Confirm New Password</label><br>
        <input type="password" name="confirm" required><br><br>

        <button type="submit">Update Password</button>
    </form>

    <br>
    <a class="link-back" href="profile.php">← Back to Profile</a>
</div>

</body>
</html>
