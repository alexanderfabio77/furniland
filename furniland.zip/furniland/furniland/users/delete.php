<?php
require "../config/db.php";
require "../middleware/admin.php";
session_start();

$id = (int) $_GET['id'];

$conn->query("DELETE FROM users WHERE UserID = $id");

header("Location: index.php");
exit();
