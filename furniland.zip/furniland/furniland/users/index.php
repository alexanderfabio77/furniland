<?php
require "../config/db.php";
require "../middleware/admin.php";

$result = $conn->query("
    SELECT UserID, Username, Email, Gender, DOB, Role
    FROM users
");
$username = $_SESSION['username'] ?? 'Admin'; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Users - Furniland</title>
    <style>
        body {
            margin: 0;
            background-color: #0f1b2b;
            color: white;
            font-family: Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        
        nav {
            background-color: #14263d;
            padding: 14px 30px; 
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        
        .nav-group {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        
        .logo {
            font-weight: bold;
            font-size: 18px; 
            color: #e5f1ff !important; 
            text-decoration: none;
            margin-right: 10px;
        }
        .logo:hover {
            color: #00c8ff !important;
        }

        
        nav a {
            color: #d0e8ff;
            text-decoration: none;
            font-size: 14px;
            margin: 0;
            padding: 5px 0;
        }

        nav a:hover {
            color: #00c8ff;
        }
        
        
        .username-link {
            color: #4fd2ff !important;
        }
        .logout-link {
            color: #ff6b6b !important;
        }


       
        .container {
            flex: 1;
            padding: 40px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            max-width: 1100px;
            margin: auto;
            border-collapse: collapse;
            background-color: #14263d;
        }

        th {
            background-color: #1d3557;
            padding: 12px;
        }

        td {
            padding: 12px;
            border-top: 1px solid #35506b;
            text-align: center;
        }

        tr:hover {
            background-color: #1a2f47;
        }

        .role-admin {
            color: #4fd2ff;
            font-weight: bold;
        }

        .btn-delete {
            background-color: #e74c3c;
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 13px;
        }

        .btn-delete:hover {
            background-color: #c0392b;
        }

        /* FOOTER */
        footer {
            background:#0d1826;
            color:#d0e8ff;
            text-align:center;
            padding:18px;
            font-size:14px;
            border-top:1px solid #23384d;
        }
    </style>
</head>
<body>

<nav>
    <div class="nav-group">
        <a href="../home.php" class="logo">Furniland</a>
        <a href="../home.php">Dashboard</a>
    </div>

    <div class="nav-group">
        <a class="username-link" href="../profile.php">
            <?= htmlspecialchars($username) ?> (Admin)
        </a>
        <a href="../logout.php" class="logout-link">Logout</a>
    </div>
</nav>

<div class="container">
    <h2>Manage Users</h2>

    <table>
        <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Gender</th>
            <th>Date of Birth</th>
            <th>Role</th>
            <th>Actions</th>
        </tr>

        <?php while ($u = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($u['Username']) ?></td>
                <td><?= htmlspecialchars($u['Email']) ?></td>
                <td><?= htmlspecialchars($u['Gender']) ?></td>
                <td><?= htmlspecialchars($u['DOB']) ?></td>
                <td class="<?= $u['Role'] === 'Admin' ? 'role-admin' : '' ?>">
                    <?= strtolower($u['Role']) ?>
                </td>
                <td>
                    <?php if ($u['Role'] !== 'Admin'): ?>
                        <a class="btn-delete"
                            href="delete.php?id=<?= $u['UserID'] ?>"
                            onclick="return confirm('Delete this user?')">
                            Delete
                        </a>
                    <?php else: ?>
                        Current Admin
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</div>

<footer>
    © 2025 Furniland. All rights reserved.<br>
    Contact: furniland-support@gmail.com
</footer>

</body>
</html>