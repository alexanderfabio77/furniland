<?php
require "config/db.php";
require "middleware/member.php";

$userId = $_SESSION['user_id'];
$username = $_SESSION['username']; 

$sql = "SELECT c.CartID, p.ProductName, c.Quantity, p.Price,
                (c.Quantity * p.Price) AS Subtotal
        FROM cart c
        JOIN products p ON c.ProductID = p.ProductID
        WHERE c.UserID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$cartItems = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Cart - Furniland</title>

    <style>

        body{
            margin:0;
            background:linear-gradient(#0f1b2b,#0b1522);
            color:white;
            font-family:Arial, sans-serif;
            display:flex;
            flex-direction:column;
            min-height:100vh;
        }
        main{ flex:1; }

        
        /* --- SINKRONISASI NAV BAR --- */
        nav{
            background:#14263d; 
            padding:14px 30px; /* Disinkronkan */
            display:flex;
            justify-content:space-between;
            align-items:center;
        }
        .nav-group {
            display: flex;
            align-items: center;
            gap: 15px; 
        }
        .logo-text{
            font-size:20px; /* Disinkronkan */
            font-weight:bold;
            color: #e5f1ff !important;
            text-decoration: none;
            margin-right: 10px;
        }
        nav a{
            color:#d0e8ff;
            text-decoration:none;
            font-size:14px;
            margin: 0; 
            padding: 5px 0; /* Disinkronkan */
        }
        nav a:hover{ color:#00c8ff; }
        
        /* CLASS AKTIF & DANGER (Menggantikan .current-page dan .logout) */
        .nav-active {
            color: #4fd2ff !important; 
            font-weight: bold;
        }
        .nav-danger { 
            color:#ff6b6b !important; 
        }
        /* --------------------------- */


        .page-title{
            text-align:center;
            margin:40px 0 30px;
            font-size: 36px;
            color: #e5f1ff;
        }

        
        .cart-wrapper{
            width:90%;
            max-width:900px; 
            margin:0 auto;
        }

        table{
            width:100%;
            border-collapse:separate; 
            border-spacing: 0;
            
            background:#122030; 
            border-radius:10px;
            overflow:hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        th{
            
            background:#1d3557; 
            padding:14px;
            text-align: left;
            font-size: 15px;
        }
        td{
            padding:14px;
            
            border-top:1px solid #1f3a50; 
            text-align: left;
            font-size: 14px;
        }
        
        
        
        th:nth-child(2), th:nth-child(3), th:nth-child(4),
        td:nth-child(2), td:nth-child(3), td:nth-child(4) { 
            text-align: center;
        }
        
        
        .total-row td {
            background: #122030; 
            border-top: 1px solid #35506b;
            font-size: 16px;
            font-weight: bold;
            color: #e5f1ff;
        }
        
        
        .btn-delete{
            
            background:#a11c2e; 
            color:white;
            border:none;
            padding:6px 14px; 
            border-radius:4px; 
            cursor:pointer;
            font-size: 13px;
            font-weight: normal;
            text-decoration: none; 
            display: inline-block;
        }
        .btn-delete:hover{ background:#c0392b; }

        
        
        
        .checkout-container {
            
            width: 100%;
            margin-top: 20px;
        }

        
        .btn-checkout{
            width:100%;
            
            background:#27ae60; 
            color:white;
            border:none;
            padding:14px;
            font-size:16px;
            border-radius:4px; 
            cursor:pointer;
            font-weight: bold;
            transition: background 0.2s;
            text-align: center; 
        }
        .btn-checkout:hover{ 
            background:#2ecc71; 
        }
        
        .empty-cart-message {
            text-align: center;
            opacity: 0.8;
            padding: 40px;
            font-size: 16px;
            background: #122030;
            border-radius: 8px;
            border: 1px solid #1f3a50;
        }
        
        
        
        footer{
            background:#0d1826;
            color:#d0e8ff;
            text-align:center;
            padding:18px;
            font-size:14px;
            border-top:1px solid #23384d;
            margin-top:40px;
        }
    </style>
</head>
<body>

<nav>
    <div class="nav-group nav-left">
        <a href="home.php" class="logo-text">Furniland</a>
        <a href="home.php">Home</a>
        <a href="catalog.php">Catalog</a>
    </div>
    <div class="nav-group nav-right">
        <a href="profile.php"><?= htmlspecialchars($username) ?></a>
        <a href="cart.php" class="nav-active">Cart</a>
        <a href="transactions.php">History</a>
        <a href="logout.php" class="nav-danger">Logout</a>
    </div>
</nav>

<main>
<h2 class="page-title">Your Shopping Cart</h2>

<div class="cart-wrapper">

<?php if ($cartItems->num_rows === 0): ?>
    <div class="empty-cart-message">
        <p>Your cart is empty. Start browsing our <a href="catalog.php" style="color: #4fd2ff;">Catalog</a> to find your next furniture!</p>
    </div>

<?php else: ?>
<table>
    <thead>
        <tr>
            <th style="width: 50%;">Product</th>
            <th style="width: 15%; text-align: center;">Qty</th>
            <th style="width: 25%; text-align: center;">Subtotal</th>
            <th style="width: 10%; text-align: center;">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $total = 0; ?>
        <?php while ($row = $cartItems->fetch_assoc()): ?>
            <?php $total += $row['Subtotal']; ?>
            <tr>
                <td><?= htmlspecialchars($row['ProductName']) ?></td>
                <td><?= $row['Quantity'] ?></td>
                <td>Rp <?= number_format($row['Subtotal'],0,',','.') ?></td>
                <td>
                    <a href="remove_from_cart.php?id=<?= $row['CartID'] ?>"
                        onclick="return confirm('Are you sure you want to remove this item from your cart?')"
                        class="btn-delete">
                        Delete
                    </a>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
    <tfoot>
        <tr class="total-row">
            <td colspan="2" style="text-align: right; padding-right: 30px;">Total</td>
            <td style="text-align: center;">Rp <?= number_format($total,0,',','.') ?></td>
            <td></td>
        </tr>
    </tfoot>
</table>

<div class="checkout-container">
    <a href="checkout.php" style="text-decoration:none;">
        <button class="btn-checkout">Checkout</button>
    </a>
</div>
<?php endif; ?>

</div>
</main>

<footer>
    © 2025 Furniland. All rights reserved.<br>
    Contact: furniland-support@gmail.com
</footer>

</body>
</html>