<?php
require "config/db.php";
require "middleware/auth.php";

$userId = $_SESSION['user_id'];
$role   = $_SESSION['role'];
$username = $_SESSION['username'];


$sql = $conn->prepare("SELECT * FROM users WHERE UserID=?");
$sql->bind_param("i", $userId);
$sql->execute();
$user = $sql->get_result()->fetch_assoc();


$profile_errors = [];
$password_errors = [];
$delete_errors = []; 
$success = "";



if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['update_profile'])) {
    
    $uname  = trim($_POST['username']);
    $email  = trim($_POST['email']);
    $gender = $_POST['gender'];
    $dob    = $_POST['dob'];

    if ($uname==="" || strlen($uname)<4 || strlen($uname)>20)
        $profile_errors[] = "Username harus 4–20 karakter.";

    $check = $conn->prepare("SELECT UserID FROM users WHERE Email=? AND UserID!=?");
    $check->bind_param("si", $email, $userId);
    $check->execute();
    if ($check->get_result()->num_rows > 0) $profile_errors[] = "Email sudah digunakan.";

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
        $profile_errors[] = "Email harus dalam format yang valid.";

    if (empty($profile_errors)) {
        $update = $conn->prepare("UPDATE users SET Username=?, Email=?, Gender=?, DOB=? WHERE UserID=?");
        $update->bind_param("ssssi", $uname, $email, $gender, $dob, $userId);
        $update->execute();

        $success = "Profile updated successfully.";
        
        
        $_SESSION['username'] = $uname;
        $username = $uname;
        $user['Username']=$uname;
        $user['Email']=$email;
        $user['Gender']=$gender;
        $user['DOB']=$dob;
    }
}


if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['update_password'])) {
    
    $current = $_POST['current'] ?? '';
    $new     = $_POST['new'] ?? '';
    $confirm = $_POST['confirm'] ?? '';
    
    $sql_pass = $conn->prepare("SELECT Password FROM users WHERE UserID=?");
    $sql_pass->bind_param("i", $userId);
    $sql_pass->execute();
    $row = $sql_pass->get_result()->fetch_assoc();


    if (!password_verify($current, $row['Password'])) {
        $password_errors[] = "Password lama salah.";
    }

    if (strlen($new) < 6) {
        $password_errors[] = "Password baru minimal 6 karakter.";
    }

    if ($new !== $confirm) {
        $password_errors[] = "Konfirmasi password tidak cocok.";
    }

    if (empty($password_errors)) {
        $hashed = password_hash($new, PASSWORD_DEFAULT);
        
        $update_pass = $conn->prepare("UPDATE users SET Password=? WHERE UserID=?");
        $update_pass->bind_param("si", $hashed, $userId);
        $update_pass->execute();
        
        $success="Password updated successfully.";
    }
}


if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['delete_account'])) {

    $confirm_pass = $_POST['confirm_delete'] ?? '';

    
    $sql_pass = $conn->prepare("SELECT Password FROM users WHERE UserID=?"); 
    if ($sql_pass === false) {
        $delete_errors[] = "Database error: Failed to prepare password query.";
        
    } else {
        $sql_pass->bind_param("i", $userId);
        $sql_pass->execute();
        $row = $sql_pass->get_result()->fetch_assoc();

        if (!password_verify($confirm_pass, $row['Password'])) {
            $delete_errors[] = "Konfirmasi password salah.";
        }

        if (empty($delete_errors)) {
            
            
            
            $delete = $conn->prepare("DELETE FROM users WHERE UserID=?");
            
            if ($delete === false) {
                $delete_errors[] = "Database error: Failed to prepare delete query.";
            } else {
                $delete->bind_param("i", $userId);
                $delete->execute();
                
                
                session_destroy();
                header("Location: auth/login.php");
                exit;
            }
        }
    }
}



if (!empty($profile_errors)) {
    $errors_to_display = $profile_errors;
} elseif (!empty($password_errors)) {
    $errors_to_display = $password_errors;
} elseif (!empty($delete_errors)) { 
    $errors_to_display = $delete_errors;
} else {
    $errors_to_display = [];
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Your Profile - Furniland</title>

<style>
    body {
        margin:0;
        background:linear-gradient(#0f1b2b,#0b1522);
        color:white;
        font-family:Arial, sans-serif;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }
    main { flex: 1; }

    
    /* --- CSS NAV BAR SINKRONISASI --- */
    nav {
        background:#14263d; 
        padding:14px 30px; 
        display:flex;
        justify-content:space-between;
        align-items:center;
    }
    .nav-group {
        display: flex;
        align-items: center;
        gap: 15px;
    }
    nav a {
        color:#d0e8ff; 
        text-decoration:none;
        font-size:14px;
        margin: 0;
        padding: 5px 0;
    }
    nav a:hover { color:#00c8ff; }
    
    .logo-text {
        font-weight:bold;
        font-size:20px; 
        color: #e5f1ff !important;
        text-decoration: none;
        margin-right: 10px;
    }
    
    /* CLASS AKTIF & DANGER */
    .nav-active {
        color: #4fd2ff !important; 
        font-weight: bold;
    }
    .nav-danger { 
        color:#ff6b6b !important; 
    }
    /* ---------------------------------- */


    
    .container {
        width:90%;
        max-width:700px;
        margin:30px auto 50px;
        display: flex;
        flex-direction: column;
        gap: 30px;
    }
    .box {
        background:#122030; 
        border:1px solid #1f3a50; 
        padding:30px;
        border-radius:10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }
    
    .delete-box {
        background: #25121c; 
        border: 1px solid #4d1f2d;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }
    .delete-box h2 {
        color: #ff6b6b; 
        border-bottom: 1px solid #4d1f2d;
    }
    .delete-box button {
        background: #ff4747; 
    }
    .delete-box button:hover {
        background: #ff6b6b;
    }
    
    
    .box h2 {
        margin-top:0;
        margin-bottom:20px;
        font-size: 20px;
        color: #e5f1ff;
        border-bottom: 1px solid #1f3a50;
        padding-bottom: 10px;
    }
    label {
        display: block;
        margin-bottom: 5px;
        margin-top: 15px;
        font-size: 14px;
        color: #c7d8f2;
        font-weight: bold;
    }
    .box label:first-of-type {
        margin-top: 0;
    }
    input, select {
        width:100%;
        padding:12px;
        margin-bottom:20px;
        border:1px solid #35506b;
        border-radius:6px;
        background:#0f1b2b; 
        color:white;
        box-sizing: border-box;
        transition: border-color 0.2s;
    }
    input:focus, select:focus {
        outline: none;
        border-color: #0088cc;
    }
    button {
        width:100%;
        padding:12px;
        background:#0088cc; 
        border:none;
        border-radius:6px;
        cursor:pointer;
        margin-top:10px;
        color:white;
        font-size:16px;
        font-weight: bold;
        transition: background 0.2s;
    }
    button:hover { background:#00aaff; }

    
    .message {
        text-align:center;
        padding: 10px 15px; 
        margin: 20px auto 0;
        width: 90%;
        max-width: 700px;
        border-radius: 6px;
        box-sizing: border-box;
    }
    .success {
        background: rgba(30, 70, 32, 0.3);
        border: 1px solid #4ade80;
        color:#4ade80;
    }
    .error {
        background: rgba(122, 42, 42, 0.3);
        border: 1px solid #ff5252;
        color:#ff5252;
    }
    .error ul {
        list-style:none; 
        padding:0;
        margin: 0;
        text-align: left;
    }
    .page-title {
        text-align:center; 
        margin: 40px 0 20px;
        font-size: 36px;
        color: #e5f1ff;
    }

    
    footer{
        background:#0d1826;
        color:#9bb4cc;
        text-align:center;
        padding:18px;
        font-size:13px;
        border-top:1px solid #23384d;
        margin-top: auto;
    }
</style>
</head>
<body>

<?php if ($role === 'Admin'): ?>
<nav>
    <div class="nav-group">
        <a href="home.php" class="logo-text">Furniland</a>
        <a href="home.php">Dashboard</a>
    </div>
    <div class="nav-group">
        <a href="profile.php"><?= htmlspecialchars($username) ?> (Admin)</a>
        <a href="logout.php" class="nav-danger">Logout</a>
    </div>
</nav>
<?php else: ?>
<nav>
    <div class="nav-group">
        <a href="home.php" class="logo-text">Furniland</a>
        <a href="home.php">Home</a>
        <a href="catalog.php">Catalog</a>
    </div>
    <div class="nav-group">
        <a href="profile.php"><?= htmlspecialchars($username) ?></a>
        <a href="cart.php">Cart</a>
        <a href="transactions.php">History</a>
        <a href="logout.php" class="nav-danger">Logout</a>
    </div>
</nav>
<?php endif; ?>

<h1 class="page-title">Your Profile Settings</h1>

<?php if ($success): ?>
<div class="message success">
    <p style="margin:0;"><?= htmlspecialchars($success) ?></p>
</div>
<?php endif; ?>

<?php if (!empty($errors_to_display)): ?>
<div class="message error">
    <ul style="list-style:none; padding:0; margin: 0;">
        <?php foreach ($errors_to_display as $e): ?>
            <li><?= htmlspecialchars($e) ?></li>
        <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>

<main class="container">

    <form method="POST" class="box">
        <h2>Update Profile</h2>
        <input type="hidden" name="update_profile">

        <label for="username">Username</label>
        <input type="text" id="username" name="username" value="<?= htmlspecialchars($user['Username']) ?>" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['Email']) ?>" required>

        <label for="gender">Gender</label>
        <select id="gender" name="gender" required>
            <option value="Male" <?= $user['Gender']==='Male'?'selected':'' ?>>Male</option>
            <option value="Female" <?= $user['Gender']==='Female'?'selected':'' ?>>Female</option>
            <option value="Other" <?= $user['Gender']==='Other'?'selected':'' ?>>Other</option>
        </select>

        <label for="dob">Date of Birth</label>
        <input type="date" id="dob" name="dob" value="<?= htmlspecialchars($user['DOB']) ?>" required>

        <button>Save Changes</button>
    </form>

    <form method="POST" class="box">
        <h2>Update Password</h2>
        <input type="hidden" name="update_password">

        <label for="current">Current Password</label>
        <input type="password" id="current" name="current" required>

        <label for="new">New Password</label>
        <input type="password" id="new" name="new" required>

        <label for="confirm">Confirm New Password</label>
        <input type="password" id="confirm" name="confirm" required>

        <button>Update Password</button>
    </form>

    <form method="POST" class="box delete-box" onsubmit="return confirm('Are you absolutely sure you want to delete your account? This action cannot be undone.');">
        <h2>Delete Account</h2>
        <input type="hidden" name="delete_account">
        
        <p style="color: #ff6b6b; font-weight: bold; margin: 0 0 10px;">
            Once deleted, your account cannot be recovered.
        </p>

        <label for="confirm_delete">Confirm Current Password</label>
        <input type="password" id="confirm_delete" name="confirm_delete" required>

        <button>Delete Account</button>
    </form>
    </main>

<footer>
    © 2025 Furniland. All rights reserved.<br>
    Contact: furniland-support@gmail.com
</footer>

</body>
</html>