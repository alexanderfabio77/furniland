<?php
require "config/db.php";
require "middleware/auth.php";
session_start();

$userId = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: profile.php");
    exit();
}

$password = $_POST['password'] ?? '';

$sql = "SELECT Password FROM users WHERE UserID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user || !password_verify($password, $user['Password'])) {
    
    $_SESSION['delete_error'] = "Password salah. Akun tidak dihapus.";
    header("Location: profile.php");
    exit();
}


$conn->begin_transaction();
try {
    
    $stmt = $conn->prepare("DELETE FROM cart WHERE UserID = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();

    
    $stmt = $conn->prepare("DELETE FROM users WHERE UserID = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();

    $conn->commit();
} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['delete_error'] = "Gagal menghapus akun.";
    header("Location: profile.php");
    exit();
}


session_destroy();
setcookie("user_id", "", time() - 3600, "/");

header("Location: home.php");
exit();
